BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"
DEFAULT_LANGUAGE = "en"
FIRST_NAMES = ['Mariko', 'Rohan', 'Fatima', 'Abdullah', 'John', 'Anjali']
DOMAINS = ['@gmail.com']